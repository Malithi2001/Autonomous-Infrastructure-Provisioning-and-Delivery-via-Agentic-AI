import { getDebugHint, getUserFriendlyError } from "@/lib/errorMessages";
import { healthService, type SystemStatus } from "@/services/api";
import { IS_MOBILE_MODE } from "@/config/runtime";
import {
  Activity,
  AlertCircle,
  Bot,
  CheckCircle2,
  FileCode2,
  GitPullRequest,
  Loader2,
  Network,
  SearchCode,
  Server,
  Settings,
  Terminal,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function statusClass(ok: boolean) {
  return ok ? "badge-success" : "badge-warning";
}

function StatusCard({
  icon: Icon,
  title,
  ok,
  message,
}: {
  icon: typeof Server;
  title: string;
  ok: boolean;
  message: string;
}) {
  return (
    <div className="card p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-600 bg-surface-900">
          <Icon size={18} className="text-primary-600 dark:text-primary-300" />
        </div>
        <span className={statusClass(ok)}>{ok ? "Ready" : "Needs setup"}</span>
      </div>
      <h2 className="mt-4 text-sm font-semibold text-ink">{title}</h2>
      <p className="mt-2 text-sm leading-6 text-ink-subtle">{message}</p>
    </div>
  );
}

export default function DashboardPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;
    healthService
      .status()
      .then((data) => {
        if (mounted) setStatus(data);
      })
      .catch((err) => {
        if (mounted) setError(getUserFriendlyError(err));
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const quickActions = [
    ...(IS_MOBILE_MODE
      ? []
      : [
          {
            label: "Show running containers",
            icon: Terminal,
            to: "/multi-agent",
          },
        ]),
    {
      label: "Analyze CI/CD log",
      icon: SearchCode,
      to: "/diagnosis",
    },
    {
      label: "Generate workflow",
      icon: FileCode2,
      to: "/diagnosis",
    },
    {
      label: "Scan GitHub repository",
      icon: GitPullRequest,
      to: "/repository-setup",
    },
    {
      label: "View Failures",
      icon: AlertCircle,
      to: "/workflow-failures",
    },
    {
      label: "Open Settings",
      icon: Settings,
      to: "/settings",
    },
  ];

  return (
    <div className="flex h-full flex-col bg-surface-900">
      <div className="shrink-0 border-b border-surface-600 bg-surface-900/90 px-4 py-4 backdrop-blur md:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl border border-primary-500/30 bg-primary-500/10">
            <Bot size={19} className="text-primary-600 dark:text-primary-300" />
          </div>
          <div>
            <h1 className="text-base font-semibold text-ink">
              Welcome to Smart DevOps Assistant
            </h1>
            <p className="text-xs text-ink-subtle">
              {IS_MOBILE_MODE
                ? "Mobile dashboard for CI/CD diagnosis through your configured backend"
                : "Desktop dashboard for CI/CD diagnosis, workflow setup, approvals, and audit history"}
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-5 md:px-6">
        <div className="mx-auto max-w-6xl space-y-4 sm:space-y-5">
          {loading ? (
            <div className="flex h-28 items-center justify-center">
              <Loader2 size={24} className="animate-spin text-primary-500" />
            </div>
          ) : error ? (
            <div className="rounded-2xl border border-red-500/30 bg-red-500/10 p-4 text-red-700 dark:text-red-200">
              <div className="flex items-start gap-3">
                <AlertCircle size={18} className="mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-semibold">{error}</p>
                  {getDebugHint(error) && (
                    <p className="mt-1 text-xs opacity-80">
                      Tip: {getDebugHint(error)}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ) : status ? (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              <StatusCard
                icon={Server}
                title="Backend API"
                ok={status.backend_api.status === "ok"}
                message={status.backend_api.message}
              />
              <StatusCard
                icon={Activity}
                title={IS_MOBILE_MODE ? "Docker Backend Note" : "Docker Status"}
                ok={status.docker.available}
                message={
                  IS_MOBILE_MODE
                    ? "Docker operations run on the backend machine, not on the phone."
                    : status.docker.message
                }
              />
              <StatusCard
                icon={GitPullRequest}
                title="GitHub Configuration"
                ok={status.github.configured}
                message={status.github.message}
              />
              <StatusCard
                icon={CheckCircle2}
                title="ML Model Status"
                ok={status.ml_model.available}
                message={status.ml_model.message}
              />
            </div>
          ) : null}

          <section className="card p-5">
            <div className="flex items-center gap-2">
              <Network size={18} className="text-primary-600 dark:text-primary-300" />
              <h2 className="text-sm font-semibold text-ink">Quick Actions</h2>
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {quickActions.map(({ label, icon: Icon, to }) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => navigate(to)}
                  className="rounded-2xl border border-surface-600 bg-surface-900/70 p-3 text-left text-sm font-medium text-ink transition hover:border-primary-500/40 hover:bg-primary-500/10 sm:p-4"
                >
                  <Icon size={17} className="mb-3 text-primary-600 dark:text-primary-300" />
                  {label}
                </button>
              ))}
            </div>
          </section>

          {IS_MOBILE_MODE && (
            <section className="card p-5">
              <h2 className="text-sm font-semibold text-ink">
                Mobile Feature Notes
              </h2>
              <div className="mt-3 grid gap-3 text-sm leading-6 text-ink-subtle md:grid-cols-2">
                <p className="rounded-2xl border border-surface-600 bg-surface-900/70 p-4">
                  The phone app must be connected to the same backend URL for
                  GitHub, ML, approvals, and audit operations.
                </p>
                <p className="rounded-2xl border border-surface-600 bg-surface-900/70 p-4">
                  GitHub webhooks need a hosted backend or a public tunnel such
                  as ngrok.
                </p>
                <p className="rounded-2xl border border-surface-600 bg-surface-900/70 p-4">
                  127.0.0.1 inside the app points to the phone itself. Use your
                  PC LAN IP for local testing.
                </p>
                <p className="rounded-2xl border border-surface-600 bg-surface-900/70 p-4">
                  Offline mode is not supported for GitHub or ML operations
                  unless the backend is reachable.
                </p>
              </div>
            </section>
          )}

          <section className="card p-5">
            <div className="flex items-center gap-2">
              <Settings size={18} className="text-blue-600 dark:text-blue-300" />
              <h2 className="text-sm font-semibold text-ink">Automation Flow</h2>
            </div>
            <div className="mt-4 grid gap-3 text-sm text-ink-subtle md:grid-cols-5">
              {[
                "User",
                "Orchestration Agent",
                "Specialized Agent",
                "Tool/Service",
                "Result",
              ].map((step, index) => (
                <div
                  key={step}
                  className="rounded-2xl border border-surface-600 bg-surface-900/70 p-4"
                >
                  <span className="badge-info">{index + 1}</span>
                  <p className="mt-3 font-semibold text-ink">{step}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
