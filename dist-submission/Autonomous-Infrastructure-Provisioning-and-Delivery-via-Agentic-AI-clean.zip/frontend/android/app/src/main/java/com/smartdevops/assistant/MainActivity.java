package com.smartdevops.assistant;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
